
import java.io.File;   
import java.io.FileInputStream;       
import java.io.InputStream;   
import jxl.Cell;   
import jxl.CellType;   
import jxl.Sheet;   
import jxl.Workbook;   
      
public class ExcelOperater    
{   
	
	public static void main(String[] args)    
    {
		jxl.Workbook readwb = null;   
        try
        {
            InputStream instream = new FileInputStream("chengji.xls");   
            readwb = Workbook.getWorkbook(instream);   
            Sheet readsheet = readwb.getSheet(0);   
            int maxColumns = readsheet.getColumns();   
            //��ȡSheet������������������   
            int maxRows = readsheet.getRows();   

            for (int i = 0; i < maxRows; i++)
            {   
            	int j=0;
            	while(j<maxColumns)
            	{   
            		Cell cell = readsheet.getCell(j, i); 
            		System.out.print(cell.getContents() + " ");
            		j++;
                }
            	System.out.println(); 
            }
           

        } 
        catch (Exception e) {
            e.printStackTrace();
        } 
        finally {
        	readwb.close();
        }   
    }   
}   
      

