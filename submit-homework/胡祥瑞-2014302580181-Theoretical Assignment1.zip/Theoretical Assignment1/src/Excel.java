

import java.io.*;
import java.util.Date;
import java.util.UUID;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.format.UnderlineStyle;
import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.write.Number;
import jxl.write.Boolean;

public class Excel {
	private String path;
    private String tableName ;
    private String[] tableCols;
    //����������
    private Workbook workbook;
    jxl.Workbook readwb = null;  
    Sheet readsheet = readwb.getSheet(0); 
    File file = new File("chengji.xls");
    public int getRows(){
   	 int maxRows = readsheet.getRows(); 
   	 return maxRows;
    }
    
    public int getColumns(){
   	 int maxColumns = readsheet.getColumns();
   	 return maxColumns;
    }
    
    public Cell[] getRows(int row){
        return readsheet == null || readsheet.getRows() < row ? null : readsheet.getRow(row);
    }
    
    public Cell[][] getCells(){
   	 int i = 0;
   	 int j = 0;
   	 Cell[][] cellArray = new Cell[i][j];
   	 for ( i = 0; i < getRows(); i++)
        {   
        	 j=0;
        	 while(j<getColumns())
        	 {   
        		 cellArray[i][j] = readsheet.getCell(j, i);          		
        		 j++;
            }         	
        }
    return cellArray;
    }
    
    public String getPath(){
   	 return this.path;
    }
    
    public void setPath(String path){
   	 this.path = path;
    }
    
    public Workbook getWorkbook(){
   	 return this.workbook;
    }
    
    public void setWorkbook(Workbook workbook){
   	 this.workbook = workbook;
    }
    public static void main(String[] args){
    	try {
    		File fileWrite = new File("c:/testWrite.xls");
    		fileWrite.createNewFile();
    		OutputStream os = new FileOutputStream(fileWrite);
   		} catch (IOException e) {
    			e.printStackTrace();
    			}
    	}
    
}
