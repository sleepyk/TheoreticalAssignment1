import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;





import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


 

public class MainOutPut {
	 public class Excel{
		 Excel excel=new Excel();
	 }
	 private String path;
     private String tableName ;
     private String[] tableCols;
     //����������
     private Workbook workbook;
     jxl.Workbook readwb = null;  
     Sheet readsheet = readwb.getSheet(0); 
     File file = new File("chengji.xls");
     public int getRows(){
    	 int maxRows = readsheet.getRows(); 
    	 return maxRows;
     }
     
     public int getColumns(){
    	 int maxColumns = readsheet.getColumns();
    	 return maxColumns;
     }
     
     public Cell[] getRows(int row){
         return readsheet == null || readsheet.getRows() < row ? null : readsheet.getRow(row);
     }
     
     public Cell[][] getCells(){
    	 int i = 0;
    	 int j = 0;
    	 Cell[][] cellArray = new Cell[i][j];
    	 for ( i = 0; i < getRows(); i++)
         {   
         	 j=0;
         	 while(j<getColumns())
         	 {   
         		 cellArray[i][j] = readsheet.getCell(j, i);          		
         		 j++;
             }         	
         }
     return cellArray;
     }
     
     public String getPath(){
    	 return this.path;
     }
     
     public void setPath(String path){
    	 this.path = path;
     }
     
     public Workbook getWorkbook(){
    	 return this.workbook;
     }
     
     public void setWorkbook(Workbook workbook){
    	 this.workbook = workbook;
     }
     public void gardes(){
     int i;
     for( i = 0; i < getRows(); i++) {
     int gardes[]=Cell(9,i);
     }
     }

	private int[] Cell(int i, int i2) {
		// TODO �Զ����ɵķ������
		return null;
	}
     
     
     
}
