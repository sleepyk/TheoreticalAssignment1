import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainOutPut {
	
	public static void main(String[] args) throws IOException
	{
		File file = new File("newScoreList.txt");
		MainOutPut mop = new MainOutPut();
		mop.processScoreTable(file);
	}
	
	public void processScoreTable(File input) throws IOException{
		try{
			File file = new File("scorelist.txt");
			ArrayList<score> classInfo = getinfo(file);
			double averagescore = getAverageScore(classInfo);
			double averagegpa = getAverageGpa(classInfo);
			BufferedWriter bw = new BufferedWriter(new FileWriter(input,true));
			for(score i:classInfo)
			{
				bw.write(i.classId+"\t"+i.className+"\t"+i.classType+"\t"+i.credit+"\t"+i.teacher +"\t"+i.department+"\t"+i.type+"\t"+i.year+"\t"+i.score+"\r\n");
			}
			bw.write("��Ȩƽ���֣� "+averagescore+"\t\t"+"��ȨGPA: "+averagegpa);
			bw.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	public static ArrayList<score> getinfo(File file)
	{
		ArrayList<score> info = new ArrayList<score>();
		try{
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file),"Unicode");
			BufferedReader br = new BufferedReader(isr);
			String line=null;
			while((line=br.readLine())!=null)
			{
				String[] arr = line.split("\\t+");
				info.add(new score(arr[0],arr[1],arr[2],Double.parseDouble(arr[3]),arr[4],arr[5],arr[6],arr[7],Double.parseDouble(arr[8])));
			}
			br.close();
			Collections.sort(info,new Comparator());			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return info;		
	}	
}
	
	








