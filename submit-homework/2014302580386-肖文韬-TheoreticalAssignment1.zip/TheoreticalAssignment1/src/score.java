
public class score {
	String classId;
	String className;
	String classType;
	double credit;
	String teacher;
	String department;
	String type;
	String year;
	double score;
	
	String[] item = new String[10];
	public String getScore(){
		return item[8];
	}
	public String getCredit(){
		return item[3];
	public score(String m_classId,String m_className,String m_classType, String m_credit,String m_teacher,String m_department,String m_type,String m_year,String m_score){
		item[0]= m_classId;
		item[1]= m_className;
		item[2]= m_classType;
		item[3]= m_credit;
		item[4]= m_teacher;
		item[5]= m_department;
		item[6]= m_type;
		item[7]= m_year;
		item[8]= m_score;		
	}

}
